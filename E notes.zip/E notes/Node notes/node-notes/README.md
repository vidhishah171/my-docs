# node-notes
Notes for node sessions
