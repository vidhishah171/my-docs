// Set timeout and set interval methods that are async and they work in node js or browser environment
//  and they're not part of javascript specifications.
// setTimeout is a timeout function which means that we can provide this function a time
//  and after a particular time it will execute whatever is inside it
// Set timeout is basically you're passing some particular time and after that time the function will get executed.

// setTimeout(cb, 2000)

console.log('Before')

// This function is also asynchronous
function greet() {
    console.log('Hello from the setTimeout')
}

setTimeout(greet, 2000)
// Greet will be waiting in the node apis to execute after 2 secs.

console.log('After')