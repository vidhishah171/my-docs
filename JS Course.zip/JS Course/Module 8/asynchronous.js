// sync behaviour: one thing at a time

// Synchronous programming will use single thread, so one operation will run at a time. Blocking: will send the server one request at a time
// and will wait for that request to be answered by the server.
// Asynchronous is non blocking, it will send multiple requests to a server at a time. We can make multiple request simultaneously.
// Increases throughput because multiple operations can run at the same time. multiple thread, but js or node doesn't have multi threads.

// Synchronous behaviour:
// there are some functions which needs to fetch data from database.
// fn1 = 10s
// fn2 = 15s
// fn3 = 5s
// total = 30s

// Asynchronous behaviour:
// fn1 = 10s
// fn2 = 15s
// fn3 = 5s
// total =  - Asynchronously(parallely)