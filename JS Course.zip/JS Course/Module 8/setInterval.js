// Set interval will set particular interval of time that after that interval/time the function will run again.
// It also takes a callback function.

function hello() {
    console.log('Hello')
}

// setInterval(hello, 1000)
// Also asynchronous function
let timer = setInterval(hello, 1000)

setTimeout(function() { // for using clearInterval need to use setTimeout again
    clearInterval(timer) // stop timer
}, 3000)