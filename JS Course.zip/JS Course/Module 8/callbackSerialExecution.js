const fs = require('fs')

// For serial order

console.log('First Line')

fs.readFile('f1.txt', cbs1)
function cbs1(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 1 data ->' + data)
    fs.readFile('f2.txt', cbs2)
}

function cbs2(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 2 data ->' + data) // executes after printing last line
    fs.readFile('f3.txt', cbs3)
}


function cbs3(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 3 data ->' + data) // executes after printing last line
}

console.log('Last Line') // prints before callback functions..prints without waiting for the callback functions.
