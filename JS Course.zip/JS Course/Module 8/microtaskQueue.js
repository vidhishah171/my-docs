// Microtask queue has always the higher priority in js than task queue.
// So whatever you write in promises will be executed first and then your callback code will be executed.
// So first promises, then callbacks.

function logA() {console.log('A')}
function logB() {console.log('B')}
function logC() {console.log('C')}
function logD() {console.log('D')}

logA();

setTimeout(logB, 0);

Promise.resolve().then(logC);

Promise.resolve().then(logA); // extra check


// process.nextTick(logD);

logD();

// logA will go to the callstack as it is a synchronous function. gets executed first.
// logB will go to the callback queue(task queue).
// logC is involved with a Promise. As taskqueue handles your callback functions, a promise will be handled by MicroTask queue.
// So it'll go to the micro task queue and not directly into the callstack.
// logD is a normal synchronous function that'll go to callstack and get executed.
// Now function in Microtask queue are prioritized over Callback/Task Queue functions. So logC will be moved to callstack.
// And gets executed.
// Now when callstack is empty and microtask queue is empty.
// So it'll check for any tasks in the callback queue(task queue). So logB will be moved to call stack and gets executed. 
// And then event loop will be closed. : jsv9000.app (Java script visualizer)
