const fs = require('fs')

console.log('First Line')
// let data = fs.readFileSync("f1.txt")
// console.log('File 1 Data ->', data)
// console.log('File 1 Data -> ' + data) // waiting to read data from file

// let data2 = fs.readFileSync("f2.txt")

// console.log('File 2 data ->' + data2)
// By default this executes parallely. So it will not wait for the first one to complete and print its result. It will just go

fs.readFile('f1.txt', cb1)
function cb1(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 1 data ->' + data)
}

fs.readFile('f2.txt', cb2)
function cb2(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 2 data ->' + data) // executes after printing last line
}


fs.readFile('f3.txt', cb3)
function cb3(err, data) {
    if(err) {
        console.log(err)
    }
    console.log('File 3 data ->' + data) // executes after printing last line
}

console.log('Last Line') // prints before callback functions..prints without waiting for the callback functions.

// callstack                        node apis
// console.log('before')            cb1 - f1 ,  cb2 - f2 
// console.log('after')             This is not any area, just a particular space that these callbacks are waiting
// now, readFile is an asynchronous method  so it will not block the execution of next lines. 
// So it'll not let the particular method execute over callstack, it will send readFile's callback function cb1 to the node api.
// now program will move ahead to next line, console.log('after')
// 🔃 - event loop: works as security guard, it'll allow these callbacks to pass into the callstack when the callstack is empty or all the
// synchronous code is finished/ the thread has finished
// callback queue: cb1, cb2
// Callback queue will take these functions inside of it, the order can be random
// Responsibility of event queue is to check if the callstack is empty and pass the functions in callback query to callstack.
// Here order can be random. -- IMP

// output
// firstline
// lastline
