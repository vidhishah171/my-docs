// Person -> Place order (coffee) -> Coffee shop -> token (Promise) -> Processing time (Promise) -> Resolved - served with your coffee
// let's try to solve these whole scenario with js.
// Coffeeshop.js

function placeOrder(drink) {
    return new Promise(function(resolve, reject) {
        if(drink==='coffee') {
            resolve('Order for Coffee is received.')
        } else {
            reject('Other orders are rejected.')
        }
    })
}

function processOrder(order) {
    return new Promise(function(resolve) { // As order is accepted so can't be rejected now.
        console.log('Order is being prepared.')
        resolve(`You ${order} is served.`)
    })
}

// placeOrder('coffee').then(function(orderPlaced) {
//     console.log(orderPlaced)
//     let orderIsProcessed = processOrder(orderPlaced)
//     return orderIsProcessed;
// }).then(function(orderServed){
//     console.log(orderServed)
// }).catch(function(err) {
    // console.log(err)
// })
 // Chaining of Promise: Solution using promises



// placeOrder('tea').then(function(orderPlaced) {
//     console.log('Success:',orderPlaced)
// }).catch(function(error) {
//     console.log('Error:', error)
// }) 

// To solve the complexity we have async await: syntatic change
// Async Await - Keywords
// Async keyword always works with the function
// Await basically waits for your promised task to complete its function whether it's resolved or rejected.

async function serverOrder() {
    try{
    let orderPlaced = await placeOrder('cofee')
    // let orderPlaced = await placeOrder('coffee')
    console.log(orderPlaced)
    let processedOrder = await processOrder(orderPlaced)
    console.log(processedOrder)
    } catch(error) {
        console.log(error)
    }
}

serverOrder()