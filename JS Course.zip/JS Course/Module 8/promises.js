// Promises in real life means a commitment that someone will do a specific task to you.
// and that depends on the a person completing that task for you.

// Promise: I'll bring groceries

// 1. Pending State
// 2. Fulfilled -> I brought groceries
// 3. Rejected -> I did not bring groceries
// 4. Settled -> fulfilled or rejected, it is settled (Promise finished)

// How to produce(construct) a promise


let myPromise = new Promise(function(resolve, reject) {
    // promise will either be fulfilled: resolve or it will be rejected: reject.
    const a = 4
    const b = 5

    setTimeout(()=>{
        if(a===b) {
            resolve('The values are equal')
        } else {
            reject('The values are not equal')
        }
    }, 2000)
})

// Pending State
console.log(myPromise)
// Promise is still in process of checking if two values are equal or not.
// How you can actually get our output if it is resolved or rejected. for that we have specific methods for promises: then and catch
// Here as we can see we have resolve and reject as a executor function, so these functions will basically execute your promise 
// And to actually get the output you need to use the other methods then and catch.

// Fulfilled - then method - consuming your promises
// Resolve method and then method are connected to each other.
// So whenever the promise will get resolved, the resolve method will send data whichever we have passed to the resolve method to the 
// parameter of then function: result
// If we have a value from resolve function, this value will go into then() function.
myPromise.then(function(result) {
    console.log(result)
}) // So that we know our promise has been fulfilled/ resolved.

// When the promise is rejected it should always be handled with a catch method.

myPromise.catch(function(result) {
    console.log(result)
}) // So that we know our promise has been rejected.

// Your promise will get Settled.