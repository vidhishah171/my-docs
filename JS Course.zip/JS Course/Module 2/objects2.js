// In JS objects are in key value pair: Arrays are an unordered collection of key-value pair
// Intializing an object with object literal notation
var person = {
    firstName: "John",
    secondName: 'Smith',
    age: 25,
    ownsCar: false
};
console.log(person)
// Accessing the property of an Object using dot notation
console.log([person.age, person.ownsCar])

// Accessing the property of an Object using bracket notation
console.log(person['firstName'])
var x= person['ownsCar']
x = true
console.log(x)
console.log(person)

var cap = {
    firstName: 'Steve',
    lastName: 'Rogers',
    age: 102,
    friends: ['Bucky Barnes', 'Bruce Banner', 'Tony Stark'],
    isAvenger: true,
    address: {
        state: 'New York',
        city: {
            name: 'Brooklyn',
            pincode: 123456
        }
    }
}

console.log(cap)
console.log(cap.friends[1]) //Bruce Banner
console.log(cap.address.city.name) //Brooklyn
cap.isAvenger = false;
console.log(cap);
cap.movies = ['age of ultron', 'civil war', 'first avenger']
console.log(cap)
delete cap.age
console.log(cap.age)

