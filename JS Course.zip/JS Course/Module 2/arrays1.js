
// Arrays provides you an orderered collection of data
var arr = [12, 'Ferrari', true, 12.46]
console.log(arr)

// Accessing the elements
var a = arr[1];
console.log(a)
console.log(arr[3])

// Replacing elements of an array by using index
arr[1] = 'Bentley'
console.log(arr)

console.log("the length of the array is:", arr.length)

// Inbuilt js array methods

var arr2 = [12,14,56,57]

console.log(arr2.pop()) // Returns the popped value

console.log('Array 2 after pop(): ', arr2)

console.log(arr2.push(100)) // Returns the length of array

console.log('Array 2 after push(): ', arr2)

//Shift method: Remove an element from the starting of an array and shift
var d = arr2.shift()
console.log('Returned(Removed) element while shift: ', d)
console.log('Array 2 after shift: ', arr2)

//Shift method: Adds an element from the starting of an array and shift
var d = arr2.unshift(102)
var d = arr2.unshift(109)
console.log('Returns length of an array after unshift: ', d)
console.log('Array 2 after unshift: ', arr2)