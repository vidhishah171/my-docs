// Encapsulation basically means hiding your data.
// You should not be allowed to use/change particular parts of the class outside of it.
// This is achieved by making all members private and providing public accessors (getters) and mutators (setters). (Blackbox)

// Keep your functions and methods inside a class only and do not expose it outside a class so that it can be changed.

function Person(_name,_age) {
    // this.name = _name
    var name = _name
    this.age = _age

    this.getName = function() {
        return name
    }
}
let person1 = new Person('Adam', 25)
console.log(person1)
console.log(person1.getName())  // Not exposed outside, canot changed from outside.

person1.name= 'Steve' // This should not be allowed
console.log(person1)
console.log(person1.getName())

