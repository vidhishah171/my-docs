// 1. Classical Inheritance
// Methods & properties form base class can be put down or can be passed into derived class.

// Using classical inheritance we can get all the properites of base class and pass them to a derived class.

// 2. Method Inheritance
// We can also inherite methods from one class to another class. : That is Method Inheritance.

class Person {
    constructor(_name, _age) {
        this.name = _name
        this.age = _age
    }

    welcome() {
        console.log(`Welcome ${this.name}!`)
    }
}

class Teacher extends Person {
    constructor(_name, _age, _classStrength) {
        super(_name, _age);
        this.classStrength = _classStrength
    }

    test() {
        super.welcome()
    }
}

class Student extends Person {
    constructor(_name, _age, _cgpa) {
        super(_name, _age);
        this.cgpa = _cgpa
    }
}

let person1 = new Person('Adam', 24)
console.log(person1)

let teacher = new Teacher('Mark', 35, 75)
console.log(teacher)
teacher.test()

let student = new Student('Steve', 21, 9.5)
console.log(student)
student.welcome()