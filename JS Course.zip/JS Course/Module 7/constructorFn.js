let oldCar1 = {
    name: 'X4',
    company: 'BMW',
    color: 'Red'
}


let oldCar2 = {
    name: 'S-class',
    company: 'Mercedes',
    color: 'White'
}

// Template with same attributes

function createCar(_name, _company, _color) { // this is now my template
    console.log(this)
    this.name = _name
    console.log(this)
    this.color = _color
    console.log(this)
    this.company = _company
    console.log(this)
    this.drive = function(){
        console.log(`I am driving ${this.name} and it is a ${this.color} ${this.company}.😍`)
    }
}

// Here we are using new keyword to create car. Whenever we use new keyword with the function and this keyword inside that function,
// it will become a constructor fn.
//  A constructor function basically points this keyword to an empty object: this points to {} now.
let car1 = new createCar('X4', 'BMW', 'Red')
let car2 = new createCar('S-Class', 'Mercedes', 'Blue')

console.log('Car 1', car1)
car1.drive()
console.log('Car 2', car2)
car2.drive()
