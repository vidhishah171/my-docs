function Person(_name, _age) {
    this.name = _name
    this.age = _age

    // this.getNameAndAge = function() {
    //     console.log(`I am ${this.name} & my age is ${this.age}.`)
    // }
}

Person.prototype.getNameAndAge = function() {
    console.log(`I am ${this.name} & my age is ${this.age}.`)
}

let person1 = new Person('Adam', 25)
let person2 = new Person('Steve', 30)
console.log(person1)
console.log(person2)
person1.getNameAndAge()


// Person: 
// person1, person2 <- Prototype Person <- Object Prototype
// looking at the output, function getNameAndAge is same for both of the object. 
// Is this a good approach to incorporate a function inside the object?
// This is actually violating the Dry Rule (Do not repeat yourself/You should not repeat your code). 
// Here we are providing fn body twice to an object. Instead we'll put this function inside Person prototype.
// Here we are not repeating the function. We just incorporated that method inside the prototype.
// And we are just asking the prototype that whenever we create an object, please give us that function with that particular object.
// It's not getting created repeatatively, it has been created only once. We're just using that method.