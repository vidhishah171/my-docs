'use strict'

console.log(this)

function displayThis() {
    console.log(this)
}
displayThis()

let myObj = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        console.log(this)
        // console.log('Name:', this.name)  // Will print Mrinal
    } // if a fn is declared inside an object, it is called as method.
}
myObj.myFn()

let anotherFn = myObj.myFn;
anotherFn();  // Undefined again

console.log("------------------------")

let myObj2 = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        function myFn2() {
        console.log(this)
    }
    console.log("Function inside function")
    myFn2();      // calling myFn2 with its own this value
 }
}

myObj2.myFn();  // Undefined