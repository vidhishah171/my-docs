let person1 = {
    firstName: 'Steve',
    lastName: 'Rogers',
    age: 30,

    printDetails: function() {
        console.log(`Hi, I am ${this.firstName} ${this.lastName} and I am ${this.age} years old.`);
    }
}

let viewDetails = function(city, power) {
    console.log(`View Details: Hi, I am ${this.firstName} ${this.lastName} and I am ${this.age} years old. 
I am from ${city}.
I have the ${power}.`);
}

let person2 = {
    firstName: 'Tony',
    lastName: 'Stark',
    age: 40,

    // printDetails: function() {
    //     console.log(`Hi, I am ${this.firstName} ${this.lastName} and I am ${this.age} years old.`);
    // } // Repeating function: Dry Rule (check prototype2.js)
}

person1.printDetails();
// person2.printDetails();

// call: Get or borrow function from another object. or we can define the fn globally & use it here when needed with call method.
person1.printDetails.call(person2) 
// Used This keyword in printDetails function will start pointing to particular calling object (person2).
viewDetails.call(person1, 'New York', 'Iron man Armour') // not dependent on particular object, arguments should be without array


// apply
viewDetails.apply(person1, ['New York', 'Iron man Armour']) // need to put arguments inside of an array
// viewDetails.apply(person1, 'New York', 'Iron man Armour') // Error: TypeError: CreateListFromArrayLike called on non-object


// bind: allows you to store your function and call at later stage of time. works at call only.
// but stores and we can call it later by calling that variable.
let myFun = viewDetails.bind(person1, 'New York', 'Iron man Armour') 
console.log(myFun)
myFun()


function Person(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
   }
   const member = new Person('Lydia', 'Hallie');
   Person.getFullName = function() {
   
   return `${this.firstName} ${this.lastName}`;
   
   };
//    console.log(member.getFullName()); // Type error

   const lydia = new Person('Lydia', 'Hallie');
const sarah = Person('Sarah', 'Smith');
console.log(lydia);
console.log(sarah); // undefined

// let shape = {
const shape = {
    radius: 10,
    diameter() {
    return this.radius * 2;
    },
    perimeter: () => 2 * Math.PI * this.radius, // Arrow functions are not allowed in object. Because they do not have their own "this"
    perimeter1() {
        return 2 * Math.PI * this.radius;
        },
   };
   
   console.log(shape.diameter());
   console.log(shape.perimeter());
   console.log(shape.perimeter1());