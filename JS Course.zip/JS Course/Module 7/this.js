'use strict'

// This keyword refers to an object that is executing the current piece of code. It references the object that is executing the 
// current function. If the function being referenced is a regular function, this references the global object.
// If the function that is being referenced is a method i an object, this references the object itself.
// In other cases (when it's not a method in an object), this refers to the global window object.
console.log(this);  // Log

// IMPORTANT
//            Non Strict Mode                         Strict 
//                                   Node JS   
// 1. console.log(this) = {}                    {}
// 2. function = Global object                  Undefined (not serving any global object)
// 3. obj -> function = Object itself           Object itself
// 4. obj -> fn -> fn = Global object           Undefined


//                                   Browser
// 1. console.log(this) = Window object         Window object
// 2. function = Window object                  Undefined (not serving any Window object)
// 3. obj -> function = Object itself           Object itself
// 4. obj -> fn -> fn = Window object           Undefined

// let a =10
a=10 // Drawback of using non-strict mod4e, if we use strict mode we'll get not defined error.
console.log(a)