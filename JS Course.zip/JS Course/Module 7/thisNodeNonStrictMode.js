console.log(this)

function displayThis() {
    console.log(this)
}
displayThis(); 
// global object: another obj inside browser or node which holds all the methods defined inside node (part of asynchronous js data)

let myObj = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        console.log(this)
        console.log('Name:', this.name)
    } // if a fn is declared inside an object, it is called as method.
}

myObj.myFn();    // calling the method using dot notation
// Output : <Object>   (because this points to the object itself in which the method was invoked.)

console.log("------------------------")


let anotherFn = myObj.myFn;
anotherFn();     // calling the same method without dot notation
// Output : <Window>   (because this now points to the window object because there is no context provided).

console.log("------------------------")

let myObj2 = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        function myFn2() {
        console.log(this)
    }
    console.log("Function inside function")
    myFn2();      // calling myFn2 with its own this value
 }
}

myObj2.myFn();