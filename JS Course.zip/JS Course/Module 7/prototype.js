// Prototype is an object that gets linked to your object by default whenever you create an object.
// Inside that prototype object you can get all the methods that you can use with your particular objects.

let myObj = {}

console.log(myObj)

let person1 = {
    name: 'Adam',
    age: 24
}
console.log(person1)
console.log(person1.hasOwnProperty('name')) // Inbuilt method: Defined in prototype object
console.log(person1.hasOwnProperty('gender'))

// constructor fn
function Person(_name, _age) {
    this.name = _name
    this.age = _age
} 

let person2 = new Person('Steve', 30)
console.log(person2)

// Object -> Object prototype - prebuilt -> pre-built methods & properites
// Constructor Fn -> Person -> Person prototype -> Object prototype - prebuilt
// If we create our own method inside constructor function, it'll get attached to Person prototype
// person1, person2 -> (Person -> Greet()) -> Object prototype
// now if we call any inbuilt method like hasOwnProperty. It'll first check that method in Person prototype first. 
// If it doesn't find it, then it'll go to check in object prototype.
// If it doesn't exist in both prototype, it will try to find it in null container(Object prototype is connected to Null container).
// Null container doesn't have anything. So it will pass Error.

// For any object it will  look for properties and methods in following order:
/*
Object itself
Object’s constructor
Object’s constructor’s prototype
Global object (usually window in browser)
*/

// For any object you'll get an object prototype by default. But whenever you try to construct a function, you'll get another prototype.
// And this prototype is available for you to use. 
// You can pass any method, create your own method/properties inside of it and use with any objects.
// Custom prototype: For you to use

// ConstructorFn:
// Person = Person Prototype -> Object Prototype -> Null Container -> Error
// Here -> is link. It points to where to look if it cannot find the property or method. And multiple links are called chaining.
// So this is basically prototype chaining. (Interview Question)