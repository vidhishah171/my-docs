// 1. Classical Inheritance
// Methods & properties form base class can be put down or can be passed into derived class.

// Using classical inheritance we can get all the properites of base class and pass them to a derived class.

class Person {
    constructor(_name, _age) {
        this.name = _name
        this.age = _age
    }
}

class Teacher extends Person {
    constructor(_name, _age, _classStrength) {
        super(_name, _age);
        this.classStrength = _classStrength
    }
}

class Student extends Person {
    constructor(_name, _age, _cgpa) {
        super(_name, _age);
        this.cgpa = _cgpa
    }
}

let person1 = new Person('Adam', 24)
console.log(person1)

let teacher = new Teacher('Mark', 35, 75)
console.log(teacher)

let student = new Student('Steve', 21, 9.5)
console.log(student)