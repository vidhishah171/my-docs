console.log(this)
// Returns Window object which carries whatever we can use with the browser.
//  Global object is basically which carries node js methods, node js fundamentals, node js ethics we actually use in js.
//  Both environments are very different. In Node, it returns a reference to itself (global).

function displayThis() {
    console.log(this)
}
displayThis(); // Window Object

let myObj = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        console.log(this)
        console.log('Name:', this.name)
    } // if a fn is declared inside an object, it is called as method.
}

myObj.myFn(); // Object itself

console.log("------------------------")

let anotherFn = myObj.myFn;
anotherFn(); // Window object, Name is blank here

console.log("------------------------")

let myObj2 = {
    name: 'Mrinal',
    age: 23,
    myFn: function() {
        function myFn2() {
        console.log(this)
    }
    console.log("Function inside function")
    myFn2();      // calling myFn2 with its own this value
 }
}

myObj2.myFn(); // Window object