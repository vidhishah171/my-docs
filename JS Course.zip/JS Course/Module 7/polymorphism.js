// poly: many
// morph: forms
// ism: way or method
// Polymorphism: A behaviour to put on many forms.
// For all these classes we have a same functions but they are behaving differently when we are calling it with any other objects.

class Animal {
    sound() {
        console.log('Animals make different sounds.')
    }
}

class Dog {
    sound() {
        console.log('Dogs bark.')
    }
}

class Cat {
    sound() {
        console.log('Cats mew.')
    }
}

let animal = new Animal()
let tommy = new Dog()
let percy = new Cat()
animal.sound()
tommy.sound()
percy.sound()