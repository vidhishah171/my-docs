// Classes are built upon the constructor functions only. New features which has been added to ES6 module of js.
// Class works as a template.

class Person {
    constructor(_name, _age) {
        this.name = _name
        this.age = _age
    }

    welcome() {
        console.log(`Welcome ${this.name}!`)
    }
}

let person1 = new Person('Adam', 19)
let person2 = new Person('Steve', 25)
let person3 = new Person('Mark', 21)

console.log(person1)
person1.welcome()
console.log(person2)
person2.welcome()
console.log(person3)
person3.welcome()

