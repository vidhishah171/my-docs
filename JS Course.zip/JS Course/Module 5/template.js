// Template Literal and multi-line strings

console.log('Scaler is Awesome.')

console.log(`Scaler is awesome!
            What do you think?`) // Multi-line strings

let a = 24
console.log('My age is', a)
console.log('My age is ' + a)
console.log(`My age is ${a}`) // Template literal