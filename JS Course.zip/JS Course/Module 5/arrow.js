let a = 2

// This arrow is known as fat arrow in javascript. Arrow functions are also called fat arrow functions.
let test1 = () => console.log(1)

let test2 = a=> console.log(a*2)


let test3 = (a, b) => {
    console.log(a+b)
}

test1() // 1
test2(5) // 5*2
test3(3,4) // 7