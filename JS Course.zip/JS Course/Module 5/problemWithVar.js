var a = 21

var a = 35 // Redeclaration of a variable is allowed, ideally shouldn't be as it creates security problems.
console.log(b)
console.log(a)

if(a===35) {
    var b = 40
    console.log(b)
}
console.log(b)
// it shouldn't allow to access a variable outside a block. (Scoping issues)
// Variables declared with var keyword are not blocked scoped, they are function scoped.
// Here b is not entitled within the If block only, we can access it from outside as well.

function test() {
    var c = 100 // Whenever we use a var keyword inside a function, it will be limited to that function only, we cannot access it from outside
    console.log(c)
}
console.log(c) // Cannot access c outside a function, function scoped.

// We should be having blocked scoped variables for better security purposes