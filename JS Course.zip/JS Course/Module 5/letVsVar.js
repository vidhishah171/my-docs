var a = 20
var a = 35
// Solution of the Redeclaration Problem
let b = 30
// let b = 45 // identifier b has already been declared
b = 49 // can reassign the let keyword
console.log(a)
console.log(b)

if(true) {
    let c = 40
    console.log(c)
}
// variables declared with var keyword are not blocked scoped they are function scoped
// Whereas variables declared with let keyword are blocked scoped

// console.log(c) // with let error comes as c is not defined, cannot access outside of the block.

// const keyword: A constant value you will be defining.
// Redeclaring is not allowed, Reassigning is not allowed, const keyword will always be block scoped.

const d = 100
// const d = 50 // redeclaration is not allowed for const keyword
// d = 60 // reassignment is also not allowed for const keyword
if(d==100) {
    // d = 8 // gives error
    const x = 50
}
const x = 30
console.log(x) // because x inside if block is block scoped

/*
Keyword   Redeclaration    Reassignment       Scoping
var          true             true         function scoped
let          false            true         block scoped
const        false            false        block scoped
*/


const obj = { foo: 1 }
obj.bar = 2
console.log(obj)