// The destructuring assignment syntax is a JavaScript expression that makes it possible to unpack values from arrays, or properties
// from objects, into distinct variables.

let arr = ['Hi', 'I', 'am', 'Vidhi', '!']
let x = arr[0]
let y = arr[3]

console.log(x, y)

let [a,b,c,d] = arr
let [e,f,g,h,i,j] = arr
console.log(a,b,c,d)
console.log(arr)
console.log(e,f,g,h+i,j)

let arr2 = ['Hi', 'I',, 'am', 'Vidhi', '!']
let [k,l,m,n] = arr2
console.log(k,l,m,n)

// Destructuring an Object

let myObj = {
    name: 'Adam',
    age: 25,
    gender: 'M'
}

let {objName, objAge, objGender} = myObj; 
let {name, age, gender} = myObj; 
// objName, objAge, objGender will be undefined, because you cannot destructure an object with different names than it's key names.
// We have to pass same key names

console.log(objName, objAge, objGender);
console.log(name, age, gender);

// if I want to destructure in different variables except key names for the object
let  {name: na, age: ag, gender: ge }=myObj;

console.log("With different key names:" , na, ag, ge);

// Default Values for missing keys in object destructuring

let person = {
    firstName : "John",
    lastName : "Doe"
};

let{firstName:ln= "Smith",lastName:fn="Jane"} = person;
console.log(ln + ", "+ fn); // Smith, Jane

let myObj1 = {
    name: 'Adam',
    age: 25,
    gender: 'M',
    address: {
        country: 'England',
        city: 'London'
    }
}

let {address}  = myObj1;   
console.log('Address', address) 
let {country,city='Nottingham'} = address;    
console.log(country+ ', '+ city) ;   // England, London
let {address:{country: co,city: ci}} = myObj1;
console.log(co+ ', '+ ci) ; // England, London