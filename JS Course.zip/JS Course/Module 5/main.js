const calculator = require('./calc')


calculator.addition(2,3)
calculator.substraction(3,2)
calculator.multiplication(4,4)
calculator.division(4,2)

// Modules(Modularity) helps you to manage your code base very well. 
// It allows you to organize and reuse the same piece of functionality across different parts of your application.


console.log(typeof (new (class { class () {} })))