// Functions are a set of code that performs specific task
// Basic function in JS

// A function is a group of reusable code which can be called anywhere in your program.

function greet() {
    console.log('Hello fellas!!')
}

greet()

// Parameters and Arguments

function add(a, b) {
    console.log(a+b)
}

add(2,3)
add(5,7)
add(10,45.6)
