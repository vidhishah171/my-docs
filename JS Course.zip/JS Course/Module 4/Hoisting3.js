// Advantage of function expression
// Hoisting is a concept that allows to move your declarations to the top without generating any error.
// So that you can intialize a variable or call your function before even declaring or defining. That is hoisitng.
console.log(a) // undefined
greet()  // Function gets executed
var b = greet;
console.log(b);
b();  


// add(2,4) // Error: Because variable is stored as undefined and you can't call a function expression using that.
// So advantage of using function expression is it throws an error when function is called before even declaring or defining it.
// That is good code practice to first declare or define your function and then call it.
var a = 'Hi'
function greet() {
    console.log('Hello from Scaler')
}

// Execution context: executes your code
// It has two phases: 1. Memory phase: Variable Environment 2. Code Execution: Where code actually starts to execute
// First memory execution happens. When it happens in js, every variable and function are stored in key value pair.
// When memory allocation happens, first of all a will get the value 'undefined'. and whatever function you define,
// always gets the whole function body stored.
// a: undefined, fn: greet() {} and after that code execution phase will begin which will store the value of a variable.

var test = function(){
    console.log('Test')
}
var test1 =test;  // Cannot hoist as function is stored in variable.
test1()

var add = function(a,b) {
    console.log(a+b)
}
add(2,4)

// Assigning the function to a variable and calling it with that variable


// Using Arrow functions
c = () => 'Arrow function says Hi';
// console.log(c);     // Output: Function C
console.log(c());   // Output: Arrow function says Hi   

/*
 * The difference between normal and arrow functions is as follows -
 * Normal functions have their own this, while arrow functions inherit the parent context’s this.       
 */                 

function Add(){
    console.log(answer); //gives undefined as variable values are assigned in the code execution phase. Just fn body is stored there.
    var answer = 2
};
Add()


function fn(){
    return 4+5;
   }
fn(3,7); // no output as we've not printed the result.
console.log(fn(3,7)) // if printed like this, output would be 9.