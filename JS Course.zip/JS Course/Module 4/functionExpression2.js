// Expression is a set of statement which will give you a specific output

var a = 2+3;
console.log(a)

// A function that does not have a name is called as anonymous function.
var add = function(a,b) {
    console.log(a+b)
    return a+b
}

var sum = add

var result = sum(3,5)
console.log('Sum function result is: ', result)