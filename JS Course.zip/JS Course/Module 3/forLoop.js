// loops are the statements that we can use to control a flow of the program and to do some repeatative tasks.

var a = 'Hello World'

// console.log(a)
// console.log(a)
// console.log(a)

// the for loop
for(var i=0;i<5;i++){
    // console.log('I am looping...')
    console.log(a + '...' + i)
}
// You have an Array and you have to square each element of that array
var num = [2,3,4,5,6,7,8]
var firstSquare = num[0]*num[0]
var squaredArr = [firstSquare]
var secondSquare = num[1]*num[1]
squaredArr.push(secondSquare)
console.log(squaredArr)

var squaredArray = []
for(var i=0;i<num.length;i++) {
    squaredArray.push(num[i]*num[i]);
}
console.log(squaredArray)