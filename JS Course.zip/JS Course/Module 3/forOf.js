// The for of sttement creates a loop iterating over iterable objects,
// including: built-in String, Array, array-like objects like NodeList and also map and set

var scores = [60, 90, 80, 75]

for(var score of scores) {
    // here score indicates the value of the array. and whereas score variable of for-in loop specifies the index of the array.
    console.log('The score is ' + score)
    // console.log(`The score is ${score}`)
}
console.log('After incrementing each score by 5.')
for(var score of scores) {
    score+=5
    console.log('The score is ' + score)
}

// method - entries()

let colors = ['Red', 'White', 'Green']

for(var [index, color] of colors.entries()) {
    // entries method will carry the indexes on the first values, and the values in the second value.
    // console.log(`${index}: ${color}`)
    console.log(index,'->', color)
}

// Strings

var str = 'Scaler'
for(var c of str) {
    console.log(c)
}

let num1=2;
// let num2='2'; 
let num2 = 02 // no error
if(num1===num2)
 console.log("true"); // ans.
else
 console.log("false");

function checkAge(data) {
    if (data === { age: 18 }) {
        console.log("You are an adult!");
    } else if (data == { age: 18 }) {
        console.log("You are still an adult.");
    } else {
        console.log(`Hmm.. You don't have an age I guess`);
    }
}
   
checkAge({ age: 18 });

   