var myScore = 99

if(myScore > 90) {
    console.log("Great job! You got a high score. You got your Bicycle!!")
} else {
    console.log('Opps, didn\'t get it this time! Try harder, you\'ll get that!!')
}