// In JS, the for-in loop allows you to loop through the properties of an object.
// The statements of code found within the loop body will be executed once for each property of the object.

var colors = {
    primary: 'Blue',
    secondary: 'Red',
    tertiary: 'White'
}

for(var color in colors) {
    // color contain keys for the object
    console.log(color + " -> " + colors[color]); // IMP: with for-in loop you must use the bracket notation for access object values.
    console.log(color + " : " + colors.color); // undefined
}

var colorsArray = ['Yellow', 'Green', 'Orange', 'Pink']

for(var color in colorsArray) {
    // here for arrays color contain index not key so it is different from above example.
    console.log(color + ' - ' + colorsArray[color])
}