// json.parse, json.stringify
// These methods will actually create separate references for our objects.
// In shallow copy only one level of integrity was maintained, second level wasn't maintained.

let firstPerson = {
    name: 'Adam',
    age: 23,
    address: {
        city: 'Lucknow',
        state: 'UP'
    }
}

let secondPerson = JSON.parse(JSON.stringify(firstPerson)) // Deep copy

secondPerson.name = 'Steve'
secondPerson.address.city = 'Delhi' 


console.log(firstPerson) // not getting changed in firstPerson.
console.log(secondPerson)