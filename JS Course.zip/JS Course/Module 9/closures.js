// lexical environment or lexical scope: function defined inside a function will always have access to its outer scope values.
// (whether its returned or not).
// here test1 function will always have access to its outer functions.

function test(){
    let a=2
    function test1() {
        console.log(a)
    }
    return test1
}

let fun = test()
console.log(fun)
fun()
test()()



function greet() {
    let name = 'Steve'
    function displayName() {
        console.log('Hi', name)
        let age = 25

        function displayAge() {
            console.log('My name is', name,'and My age is',24) // lexical scope: access to outer scope
        }
        return displayAge
    }
    return displayName
}

let g1 = greet()
// console.log(g1)
// g1()
let g2 = g1() // prints Hi Steve
console.log('G2 function:',g2)
g2()

// this is what closures are.