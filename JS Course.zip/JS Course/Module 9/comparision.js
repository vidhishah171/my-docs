let a = 2
let b = '2'

console.log(a==b) // loose checking: just checks for the value
console.log(a===b) // strict checking: check for value and type
