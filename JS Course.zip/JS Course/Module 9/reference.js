// Reference datatypes: mutable, whenever we copy and change the value of property, the value will be changed, Heap memory
// Objects, Arrays, Functions

// Heap
// here when we talk about reference data type, we do not store values in the particular stack, instead we store pointers(reference to values).
// these pointers will actually map to the particular memory locations inside the heap where the object has been stored. 
// fp object is stored here.
// So when you assign fp object to sp object, basically a pointer will be assigned to sp. 
// Whereas this pointer maps to the location K where the actual object is stored in Heap.

// Stack
// sp -> Pointer to fp object (when sp = fp)
// fp -> Pointer to fp object
// So here, fp and sp maps to the same memory location created in heap. 
// So whenever you'll change in the sp's property, the change will be reflected to the object stored in heap where both the pointers are pointing to.
// So change will be done in fp and sp both as there's the same one object is getting changed.


// So whenever we make copy of an object, the changes will be reflected in the both original and copied object.

let firstPerson = {
    name: 'Adam',
    age: 23
}

let secondPerson = firstPerson

firstPerson.name = 'Steve'

console.log(firstPerson)
console.log(secondPerson) // both the person's name value has been changed
