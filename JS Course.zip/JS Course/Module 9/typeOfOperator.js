let a = 2
console.log(typeof a)

let b = 'scaler'
console.log(typeof b)

let c = true
console.log(typeof c)


let myObj = {
    name: 'Vidhi',
    age: 24
}

console.log(typeof myObj)

let arr = [1,2,3,'f']
console.log(typeof arr) // always returns obj for array. in js array is object.
