// Primitive datatypes: Basically immutable. It'll not get mutated, Stack memory
// Nunbers, Strings, Null, Boolean, Undefined

// Reference datatypes: mutable, whenever we copy and change the value of property, the value will be changed, Heap memory
// Objects, Arrays, Functions

// Stack
// sp -> Adam (The value itself gets assigned in this case sp = fp)
// fp -> Adam, gets changed to: Steve
// Now if we change the fp value to Steve, it'll be changed to Steve but sp value will still remain same.
// SourceBuffer, one will print Steve and second will print Adam.

let firstPerson = 'Adam'

let secondPerson = firstPerson

firstPerson = 'Steve'

console.log('firstPerson', firstPerson)
console.log('secondPerson' , secondPerson) // secondPerson's value is still Adam
