// What if we do not want to affect the original object.
// Spread operator {...} Three dots is the symbol of spread operator.
// Takes out the first properties inside your object and creates a separate reference.

let firstPerson = {
    name: 'Adam',
    age: 23,
    address: {
        city: 'Lucknow',
        state: 'UP'
    }
}

let secondPerson = {...firstPerson} // Shallow copy
secondPerson.address = {...firstPerson.address}

secondPerson.name = 'Steve'
secondPerson.address.city = 'Delhi' 
// only creates separate reference for first properties and not nested ones. (Problem with spread operator)
// To handle this you can use spread operator again, add a comma over {...firstPerson} and spread this particular nested object again.
// But it becomes tedious. for the solution we have deep copy.


console.log(firstPerson) // name not getting changed in firstPerson, but city is changed.
console.log(secondPerson)


