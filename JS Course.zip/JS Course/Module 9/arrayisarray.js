// Special kind of method in js to check what you have defined is array or not.

let arr = [1,2,3,'f']
console.log(Array.isArray(arr)) // if it's an array it returns true.

console.log(typeof arr)

let a=2 
console.log(Array.isArray(a)) // if it's an array it returns true, else false.

