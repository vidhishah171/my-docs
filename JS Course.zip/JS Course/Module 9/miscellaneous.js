// Every variable in js has true or false values.
// Primitive data types are stored in stack memory, reference data types are stored in heap memory.
// How memory of primitive and reference data types work?
// Closures: IMPORTANT
// Currying: One application of clousre is currying.
// type of Operator: Whenever you're passing a value inside of this operator, it'll check for the type of the value: String/number/object.
// Arrays in js are object only. Array.isArray to check it it's an array. 
// Because passing array to type of operator will always return as object only.