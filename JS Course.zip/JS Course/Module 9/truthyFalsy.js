// In js, there's concept that every value has a boolean value.

// let a = 2 // truthy
// let a = 0 // falsy
// let a = 'Scaler' // truthy
// let a = '' // falsy
// let a // falsy(undefined)
// let a = [] // truthy
// let a = {} // truthy
// let a = "0" // truthy
let a = "false" // truthy


if(a) {
    console.log('I am Truthy.')
} else {
    console.log('I am Falsy.', a)
}


// let x = false===""
// x? console.log("trueee") : console.log("falsee")

// Falsy values:
// false
// 0 (zero)
// -0 (minus zero)
// 0n (BigInt zero)
// '', "", `` (empty string)
// null
// undefined
// NaN
// console.log([]===true)



(function () {
    // true || false || false
    if((-100 && 100 && "0") || [] === true || 0) {
        console.log(1); //1
//      true || false 
        if([] || (0 && false)) {
            console.log(2); //2
        }
        // true && false && true: false
        if(Infinity && NaN && "false") {
            console.log(3);
            if("") {
                console.log(4);
            }
        } else {
            console.log(5); //5
            // (true || false) && !(false && false): true && true
            if(({} || false === "") && !(null && undefined)) {
                console.log(6); //6
            }
        }
    }
})();