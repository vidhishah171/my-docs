// you need the sum of every element in an array: Imparative way
// Reduce and reduceRight methods follow a common operation called Inject and fold. (IMP)

let num = [1,2,3,4,10]
let sum = 0; // accumulator (accumulating values one by one)
for(let i=0;i<num.length;i++) {
    sum = sum+ num[i]
}
console.log(sum)

// Reduce

let reducedSum = num.reduce(function(acc, value) { // value would be array value turn by turn
    let updatedSum = acc+value // 0 + 1 = 1 accumulator, 1 + 2 = updatedSum = acc, 3 + 3
    console.log("acc:", acc, 'updatedSum:', updatedSum)
    return updatedSum
}, 0) // base value of accumulator
// Accumulators value will be updated with the returned type(updatedSum).
// And later on the next value will be added to that particular sum only.

console.log('reducedSum:', reducedSum);


let product = num.reduce(function(acc,value) {
    let updatedProduct = acc*value
    return updatedProduct
}, 1)
console.log('Product:', product);
