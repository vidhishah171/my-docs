// Callback function is a function that is passed into another function as an argument. 
// This function can then be invoked at a later stage of TimeRanges.
// In JS< functions are objects, functions can be passed as arguments.

function printFirstName(firstname, cb) {
    console.log(firstname)
    cb('Rogers') // calls the printLastName function.
}

function printLastName(lastname) {
    console.log(lastname)
}

printFirstName('Steve', printLastName) // callback: printLastName

// function printLastName(lastname) {
//     console.log(lastname)
// }

// printLastName('Rogers')

const isEven = (n) => {
    return n%2==0
}

let printResult = (evenFunction, num) => {
    const isNumEven = evenFunction(num);
    console.log(`The number ${num} is an Even Number: ${isNumEven}.`)
    if (isNumEven){
        console.log(`${num} is Even`)
    } else{
        console.log(`${num} is Odd`)
    }
}

printResult(isEven, 16);


// /*
// In JavaScript, you can pass a function as an argument to another function and call it inside the parent function using parentheses. 
// A Promise object represents the eventual completion or failure of an asynchronous operation and its resulting value.
// In JavaScript, you can pass functions as parameters to other functions and use them like any other variable. You can also call one function from within another
// A Promise object represents the eventual completion or failure of an asynchronous operation and its resulting value.
// Time Ranges in JavaScript:
// - A time range object represents a period of     time with a start and end point.
// - The Date object provides methods for working with individual dates and times.
// - The TimeRange object extends the Date object to represent a duration or interval of time.
// */
// class TimeRange {
//     constructor(startDate, endDate) {
//       this.startDate = startDate;
//       this.endDate = endDate;
//     }
  
//     overlaps(timeRange) {
//       /*
//        * Determine whether two time ranges overlap.
//        * @param {TimeRange} timeRange - The other time range to compare against.
//        */
//       // If either date is null, it can't possibly overlap. 
//       if (!this.startDate || !this.endDate || !timeRange.startDate || !timeRange.endDate) {
//           return false;
//       }
  
//       // Check if any part of one range is within the other range.
//       return (this.startDate <= timeRange.startDate && this.endDate > timeRange.startDate) ||
//              (timeRange.startDate <= this.startDate && timeRange.endDate > this.startDate);
//     }
  
//     contains(date) {
//       /*        
//        * Determine whether a given date falls within the current time range.
//        * @param {Date} date - The date to check.
//        */
//       return this.startDate <= date && date <= this.endDate;
//     }
//   }

// let tr1 = new TimeRange(        new Date("2021-09-30T08:30:00Z"), new Date("2021-09-30T09:30:00Z"));
// let tr2 = new TimeRange(new Date("2021-09-30T09:45:00Z"), new Date("2021-09-30T10:15:00Z"));

// console.log(tr1.overlaps(tr2));                               // true
// console.log(tr2.contains(new Date("2021-09-30T09:00:00Z")));// false

