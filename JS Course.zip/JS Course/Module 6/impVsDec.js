// Imperative           
// 1. Focuses on how to go about a problem   
// 2. Approach, Structure, Logic 

// Declarative
// 1. Focuses on What to achive from the problem
// 2. Problem statement and desired outcome      
// 3. Leaves implementation details up to the language/framework

// We'll be given a number and we have to check that if the square of that number is even or not.

// Imperative way of writing code
const a = 4
const aSquared = a*a
let isEven;

if(aSquared%2==0) {
    isEven = true;
} else {
    isEven = false;
}
console.log(isEven)

// Declarative way of writing code: Better way
// Functional programming
const checkForSquare = (x) => ((x*x%2===0)? true:false)
console.log(checkForSquare(5))