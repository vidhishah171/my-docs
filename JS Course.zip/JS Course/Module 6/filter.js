// you have to check for even numbers in an array and put them in a spearate array: Imparative code

let numbers = [1,2,20,35,12,17,46]
let evenArray = []

for(let i=0;i<numbers.length;i++) {
    if(numbers[i]%2==0) {
        evenArray.push(numbers[i])
    }
}
console.log("Even Numbers: ",evenArray);

// Filter method
// Filter returns a new array with all those elements that matches the specific condition.
// If the condition is true it will return the element for that condition and if it is false it will discard that element.

evenArray = []
const isEven = number => number % 2 == 0
numbers.filter(isEven).forEach(item => evenArray.push(item))

console.log("Filter Method Even Numbers: ",evenArray);

let evenNum = numbers.filter(function(n) {
    return n%2==0
})
console.log(evenNum)


const transactions = [1000,3000,4000,2000,-898,-3800,-4500]

let creditedTransactions = transactions.filter((amount) => amount>0)
console.log(transactions , creditedTransactions)
// No concept of mutability, not changing the old array, creating a new array based on filter conditions.

// Which of the following is/are true regarding the filter() method in javascript?

// The filter() method creates a new array filled with elements that pass a test provided by a function.
// The filter() method does not execute the function for empty elements.
// The filter() method does not change the original array.