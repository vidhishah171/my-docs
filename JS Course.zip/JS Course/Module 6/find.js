// find works as filter but returns only the first element which satisfies the condition.
// Find returns the first element of an array that satisfy the condition.

const transactions = [1000,3000,4000,2000,-898,3800,-4500]

let firstWithdrawl = transactions.find(function(n) { return n<0})
console.log("First withdrawal:",firstWithdrawl);  // First withdrawal: -898

// findIndex

let firstWithdrawlIndex = transactions.findIndex(function(n) { return n<0})
console.log("First withdrawal Index:",firstWithdrawlIndex);  // First withdrawal: -898

transactions[firstWithdrawlIndex] = -500
console.log("Modified Transaction list: ",transactions);  