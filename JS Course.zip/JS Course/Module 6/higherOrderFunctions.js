// Higher order functions are functions that operate on other functions, either by taking them as arguments or by returning them.
// In simple words, A higher-order function is a function that receives a function as an argument or returns the function as output.

// Callback function is passed to another function 
// and higher order function receives a function as an argument or returns the function as an output.
// So, you're using higher order functions, tell me more about how you shift your problems to somebody else.

let arr = [1,2,3,4,5]
let squaredArr = []
// don't focus on the control flow here. Just think of what needs to be done. Functional programming - Declarative way

for(i in arr) {
    squaredArr.push(arr[i]*arr[i])
}
console.log(squaredArr)

arr.forEach(function(num) {squaredArr.push(Math.pow(num,2))}) // this is called callback function
console.log(squaredArr); //[1, 4, 9,  16, 25]

// Map: Map will loop through every element of your array and will perform specific operations that you have provided. - Scaler
// Map will always return you a new array with your results.

// Blackbox
// The map() method creates a new array with the results of calling a provided function on every element in the original array. 
// const squareAndMultiplyByTwo = (x) => x * x * 2;
// const numbers = [1, 2, 3];
// const results = numbers.map(squareAndMultiplyByTwo);
// console.log(results); // [2, 8, 18]

// Declarative way
const num = [1,2,3,4,5]
const squaredNum = num.map(function(n) {
    return n*n
})
console.log('Using Map:' ,squaredNum) // [1, 4, 9, 16, 25]

const transactions = [1000,3000,4000,2000,-898,3800,-4500]
const intoDollar = 80;

let transactionsInDollarsF = transactions.map(function(t) { return t/intoDollar })
let transactionsInDollars = transactions.map(t => (t/intoDollar).toFixed(0)) // transactions.map((t) => {return (t/intoDollar).toFixed(0)})
console.log(transactionsInDollarsF, transactionsInDollars)

let transactionForEach = transactions.forEach((amount) => {return (amount/intoDollar).toFixed(0)})

console.log(transactionForEach) // can return in map and can't return anything in forEach

let transactionForEach1 = transactions.forEach((amount) => {console.log((amount/intoDollar).toFixed(0))})

console.log(transactions, transactionForEach1) // can return in map and can't return anything in forEach
