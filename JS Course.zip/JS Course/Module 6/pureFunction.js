// A pure function is a function which:
// 1. Given the same input, always returns the same output.
// 2. Produces no side effects.  The function does not modify any data or shared state outside of its scope.
// 3. Does not rely on global variables or mutable data structures to store and manipulate state.
// In other words, it's a function that can be reasoned about without considering external factors.
    function add(x, y) {    
        return x + y;
    }

console.log("Expected Output:", "5");
console.log("Actual Output:", add(2, 3));

if (add(2, 3) !== 5) {
    console.error('Test failed');
} else {
    console.log('Test passed');
}

function multiply(a, b) {
    let result = 0;
    for (let i=0; i<b; i++) {
        result += a;
    }
    return result;
}

console.log("\nExpected Output:", "6");
console.log("Actual Output:", multiply(2, 3)); 

if (multiply(2,  3) !== 6 || multiply(1,  0) !== 0 || multiply(-1, -1) !== 1) {
    console.error('Tests failed');
} else {
    console.log('Tests passed');
}

const objA = { val:  1 };
const objB = { val:  2 };   

function copyObj(obj) {
    return { val: obj.val };
}

console.log('\nExpected Output:', 'Object { val: 1 }', '\n                 Object { val:  2 }');
console.log('Actual Output:', copyObj(objA),'\n              ', copyObj(objB));

// My code
console.log('My Code:')
// Same code but different output, due to external factors. Impure function
var a=2
function addImpure(x) {
    console.log(x+a)
    a++
}

addImpure(2)
addImpure(2)
addImpure(2)

// Pure function: We always get the same output.
// console.log is an external resource that method uses which is not part of the function. Using console.log is a side effect.
function addPure(x, a) {
    console.log(x+a)
}

// now console.log is outside of the function body, so not depending on any external factor. So Pure function.
// Whatever would be the arguments, it will give the output according to that only. 
// So the output will never change and always give what is expected out of it if the same input is given. No side effects.
function addPure1(x, a) {
    console.log(x+a)
}

console.log(addPure1(2,3))
console.log(addPure1(2,3))
console.log(addPure1(2,3))
