// How can we chain methods in JS.
// Chaining is process, taking an output from one method and passing that to another method in the same line.

let arr = [
    {name: "A", age: 14, gender: "M"},
    {name: "B", age: 34, gender: "M"},
    {name: "C", age: 24, gender: "F"},
    {name: "D", age: 44, gender: "F"},
    {name: "E", age: 44, gender: "M"},
    {name: "F", age: 28, gender: "F"},
    {name: "G", age: 36, gender: "M"},
    {name: "H", age: 47, gender: "F"},
]

// Age of all the Men (Males)

let males = arr.filter(person => person.gender=="M")
let maleFunction = arr.filter(function(obj) {
    return obj.gender == 'M'
})
console.log(males, maleFunction) // Same output

let agesOfMales = males.map(male => male.age)
console.log(agesOfMales)

let ageOfMalesChaining = males.filter(person => person.gender=='M').map(obj => obj.age)
// Sending output of one method to another method. like a pipe works
console.log("Age of Males using chaining : ", ageOfMalesChaining)

const transactions = [1000,3000,4000,2000,-898,3800,-4500]
// From the transactions array filter out positive elemtns and calculate the total amoumt.

let totalCreditedAmount = transactions.filter(transaction => transaction>0).reduce((acc,value) => acc+value,0)
console.log("TotalCreditedAmount:", totalCreditedAmount)

// Hint: Use filter and reduce to acheive this.