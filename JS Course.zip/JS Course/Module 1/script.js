console.log('Hello from the Script file')

let a = 17

console.log(a)

let b = 12+14

console.log(b)

a=3000;
console.log("I love you", a,"!");
