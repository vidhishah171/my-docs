var a = 20
// a is an identifier: a particular name given to a variable to identify it.
console.log(a)

var $greet = 'hello'
// greet is also an identifier, but with the keyword "var" added in front of it
// identifier names can contain $ and _ and can also start with them.
console.log($greet)