package springfirst.springshape;

import java.util.List;

public class ShapeTypes {
	private Shape circle;
//	private Shape rectangle;
//	private Shape triangle;
	public Shape getCircle() {
		return circle;
	}
	public void setCircle(Shape circle) {
		this.circle = circle;
	}
//	public Shape getRectangle() {
//		return rectangle;
//	}
//	public void setRectangle(Shape rectangle) {
//		this.rectangle = rectangle;
//	}
//	public Shape getTriangle() {
//		return triangle;
//	}
//	public void setTriangle(Shape triangle) {
//		this.triangle = triangle;
//	}
	
//	private List<Shape> shapes;
//	
//	public List<Shape> getShapes() {
//		return shapes;
//	}
//	public void setShapes(List<Shape> shapes) {
//		this.shapes = shapes;
//	}
	
	public void draw() {
		
//		for(Shape s:shapes) {
//			System.out.println("Shape type: "+s.getType()+" And size: "+s.getSize());
//		}
		System.out.println("Circle type: "+getCircle().getType()+" And size: "+getCircle().getSize());
//		System.out.println("Rectangle type: "+getRectangle().getType()+" And size: "+getRectangle().getSize());
//		System.out.println("Triangle type: "+getTriangle().getType()+" And size: "+getTriangle().getSize());

	}
}
