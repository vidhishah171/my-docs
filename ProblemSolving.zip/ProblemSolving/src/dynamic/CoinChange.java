package dynamic;

import java.util.Arrays;

public class CoinChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
//	Recursive function, handle base case, for loop, n = rs, return the minimum of 3.
	private static int minCoins(int n, int a[]) {
		int count = 0;
		if(n==0) {
			return 0;
		}
		for(int i=0;i<a.length;i++) {
			if(n-a[i]>0) {
			minCoins(n-a[i],a));
			} else if(n-a[i]<0) {
				continue;
			} else {
				return ++count;
			}
		}
		return 0;
	}

}
