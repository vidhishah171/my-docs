package dynamic;

public class Fibonacci {

	
	public static void main(String[] args) {
//		 0 1 1 2 3 5 8
//		fib(6) = fib(5) + fib(4)
//		 	 6
//		 	| |
//		 	5 4
//		   | |
//		   4 3
//		fib(n) = fib(n-1) + fib(n-2)
		node of recursive calls = number of nodes in the tree.
				4      1
				| |
				3 3    *2
				total nodes 15, 4 levels = 2^n - 1 = o(2^n) time
//				Number of stacks = space complexity
	}
}
