package com.firebasepractice.service.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CrudUser {

	private String documentId;
	
	private String firstName;
	
	private String profession;
}
