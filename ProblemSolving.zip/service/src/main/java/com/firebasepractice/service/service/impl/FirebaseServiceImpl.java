package com.firebasepractice.service.service.impl;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.firebasepractice.service.entity.CrudUser;
import com.firebasepractice.service.service.FirebaseService;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.FirebaseApp;
import com.google.firebase.cloud.FirestoreClient;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

@Service
public class FirebaseServiceImpl implements FirebaseService {

	private DatabaseReference databaseReference;

	@Autowired
	public FirebaseServiceImpl(FirebaseApp firebaseApp) {
		if (FirebaseApp.getApps().isEmpty()) {
            firebaseApp.initializeApp();
        }
		this.databaseReference = FirebaseDatabase.getInstance().getReference();
	}

	@Override
	public void saveEntry(String key, Object value) {
		// TODO Auto-generated method stub
		databaseReference.child("entries").child(key).setValueAsync(value);

	}

	@Override
	public String updateEntry(CrudUser user) throws InterruptedException, ExecutionException {

		Firestore dbFirestore = FirestoreClient.getFirestore();
		ApiFuture<WriteResult> collectionsApiFuture = dbFirestore.collection("Users").document(user.getDocumentId()).set(user);
		return collectionsApiFuture.get().getUpdateTime().toDate().toString();
	}

	@Override
	public String createEntry(CrudUser user) throws InterruptedException, ExecutionException {

		Firestore dbFirestore = FirestoreClient.getFirestore();
		ApiFuture<WriteResult> collectionsApiFuture = dbFirestore.collection("Users").document(user.getDocumentId()).set(user);
		return collectionsApiFuture.get().getUpdateTime().toString();
	}

	@Override
	public CrudUser getEntry(String documentId) throws InterruptedException, ExecutionException {

		Firestore dbFirestore = FirestoreClient.getFirestore();
		DocumentReference documentReference = dbFirestore.collection("Users").document(documentId);
		ApiFuture<DocumentSnapshot> future = documentReference.get();
		DocumentSnapshot document = future.get();
		CrudUser user;
		if(document.exists()) {
			user = document.toObject(CrudUser.class);
			return user;
		}
		return null;
	}

	@Override
	public String deleteEntry(String documentId) throws InterruptedException, ExecutionException {

		Firestore dbFirestore = FirestoreClient.getFirestore();
		ApiFuture<WriteResult> writeResult = dbFirestore.collection("Users").document(documentId).delete();
		return "Successfully Deleted: " + documentId + " at " + writeResult.get().getUpdateTime().toDate() + ".";
	}

}
