package com.firebasepractice.service.service;

import java.util.concurrent.ExecutionException;

import com.firebasepractice.service.entity.CrudUser;

public interface FirebaseService {

	void saveEntry(String key, Object value);

	String updateEntry(CrudUser user) throws InterruptedException, ExecutionException;

	String createEntry(CrudUser user) throws InterruptedException, ExecutionException;

	CrudUser getEntry(String documentId) throws InterruptedException, ExecutionException;

	String deleteEntry(String documentId) throws InterruptedException, ExecutionException;
}
