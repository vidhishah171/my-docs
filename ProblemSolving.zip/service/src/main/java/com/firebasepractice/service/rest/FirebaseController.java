package com.firebasepractice.service.rest;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.firebasepractice.service.entity.CrudUser;
import com.firebasepractice.service.service.FirebaseService;

@RequestMapping("/firebaseapp")
@RestController
public class FirebaseController {

	@Autowired
	private FirebaseService firebaseService;
	
	
	@GetMapping("/save")
	void getEntryToFirebase() {
		System.out.println();
//		this.firebaseService.saveEntry(key, value);
	}
	
	@PostMapping("/save")
	void saveEntryToFirebase(@RequestParam String key, @RequestParam String value) {
		this.firebaseService.saveEntry(key, value);
	}
	
	@PostMapping("/create")
	public String createEntry(@RequestBody CrudUser user) throws InterruptedException, ExecutionException{
		
		return firebaseService.createEntry(user);
	}
	
	@GetMapping("/get")
	public CrudUser getEntry(@RequestParam String documentId) throws InterruptedException, ExecutionException{
		
		return firebaseService.getEntry(documentId);
	}
	
	@PutMapping("/update")
	public String updateEntry(@RequestBody CrudUser user) throws InterruptedException, ExecutionException{
		
		return firebaseService.updateEntry(user);
	}
	
	@DeleteMapping("/delete")
	public String deleteEntry(@RequestParam String documentId) throws InterruptedException, ExecutionException{
		
		return firebaseService.deleteEntry(documentId);
	}
}
