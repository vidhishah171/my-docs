package com.example.demo.person.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.person.entity.Person;
import com.example.demo.person.service.PersonService;

@RestController
@RequestMapping("/person")
public class PersonController {
		
	@Autowired
	private PersonService personService;
	
	@PostMapping("/save")
	public Person savePerson(@RequestBody Person person) {
		return personService.save(person);
	}
	
	@GetMapping("/view/getEmployees")
	public List<Person> viewPerson() {
//		String s = "";
//		for(Person p:service.view()) {
//			s+=p.getId()+". "+p.getFirstName()+" "+p.getLastName()+" is "+p.getAge()+" years old.\n";
//		}
		return personService.view();
	}
	
	@PutMapping("/update")
	public String updatePerson(@RequestBody Person person) {
		Person p=personService.update(person);
		if(p!=null)
			return "This entry has been updated with Name: "+p.getFirstName()+" "+p.getLastName()+" And age: "+p.getAge();
		else
			return "Entry not updated, Please enter correct id.";
	}
	
	@DeleteMapping("/delete/{id}")
	public String deletePerson(@PathVariable(value="id") String id) {
		return personService.delete(id);
	}
	
	@PatchMapping("/changeFirstName/{id}/{firstName}")
	public String patchPerson(@PathVariable(value="id") String id, @PathVariable String firstName) {
		return personService.patch(id, firstName);
	}
}
