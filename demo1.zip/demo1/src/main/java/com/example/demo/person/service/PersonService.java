package com.example.demo.person.service;

import java.util.List;

import com.example.demo.person.entity.Person;

public interface PersonService{
	Person save(Person person);
	List<Person> view();
	Person update(Person person);
	String delete(String id);
	String patch(String id, String firstName);
}
