package com.example.demo.person.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.person.entity.Person;
import com.example.demo.person.repository.PersonRepository;

@Service
public class PersonServiceImpl implements PersonService {
	
	@Autowired
	private PersonRepository personRepository;
	
//	@Autowired
//	private MongoTemplate mongoTemplate;
	
	@Override
	public Person save(Person person) {
		// TODO Auto-generated method stub
		System.out.println(person.getFirstName()+" "+person.getLastName()+" is "+person.getAge()+" year old!");
//		return person.getFirstName()+" "+person.getLastName()+" is "+person.getAge()+" year old!";
//		return personRepository.save(person);
		return personRepository.insert(person);
	}

	@Override
	public List<Person> view() {
		// TODO Auto-generated method stub
		return personRepository.findAll();
	}

	@Override
	public Person update(Person person) {
		// TODO Auto-generated method stub
		Person p=personRepository.findById(person.getId()).orElse(null);
		if(p!= null) {
			p.setFirstName(person.getFirstName());
			p.setLastName(person.getLastName());
			p.setAge(person.getAge());
			return personRepository.save(p);
		}
		else {
			return null;
		}
	}

	@Override
	public String delete(String id) {
		// TODO Auto-generated method stub
		Person p = personRepository.findById(id).orElse(null);
		if(p!=null) {
			personRepository.deleteById(id);
			return "Entry with id: "+id+" deleted successfully.";
		}
		else
			return "Cannot find the entry with id: "+id+".";
	}

	@Override
	public String patch(String id, String firstName) {
		// TODO Auto-generated method stub
		Person p=personRepository.findById(id).orElse(null);
		if(p!= null) {
			p.setFirstName(firstName);
			personRepository.save(p);
			return "FirstName changed successfully to "+p.getFirstName()+".";
		}
		else {
			return "Cannot change firstName, please Enter valid id.";
		}
	}
}

