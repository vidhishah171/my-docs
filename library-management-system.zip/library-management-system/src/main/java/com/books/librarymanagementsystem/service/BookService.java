package com.books.librarymanagementsystem.service;

import com.books.librarymanagementsystem.entity.Book;

public interface BookService {

	String addBook(Book book);
}
