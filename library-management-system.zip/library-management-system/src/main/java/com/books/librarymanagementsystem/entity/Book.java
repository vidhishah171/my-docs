package com.books.librarymanagementsystem.entity;

import java.time.Year;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import com.books.librarymanagementsystem.entity.base.Auditable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@SuppressWarnings("deprecation")
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "books")
public class Book extends Auditable {
	
	
	@NotBlank(message = "Book title must not be blank.")
	private String title;
	
	@NotBlank(message = "Book title must not be blank.")
	private String author;
	
	@NotNull
	private Year publicationYear;

}
